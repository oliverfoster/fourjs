carota
======

Simple, flexible rich text rendering/editing on HTML Canvas

Live demo (very self-explanatory!): http://earwicker.com/carota/

Open sourced under the very permissive MIT license - http://opensource.org/licenses/MIT

More information: http://smellegantcode.wordpress.com/2013/11/04/rich-text-editor-in-the-html-canvas-part-1-introducing-carota/
